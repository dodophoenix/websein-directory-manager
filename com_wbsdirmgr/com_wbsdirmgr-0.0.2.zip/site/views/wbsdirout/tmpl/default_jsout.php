<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

// Overwrite this file with an javascript output that builds a galery
echo "<h1>I am an empty JS-Output Template. Overwrite me please !</h1>";